import React, { useState } from 'react';
import moment from 'moment';
import { Card, Col, Modal, Button, ListGroup } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

export const InnerCard = ({ ad, userItems }) => {
  const navigate = useNavigate();
  const [show, setShow] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [successMessage, setSuccessMessage] = useState(false);

  const time = moment(ad.createdAt).fromNow();

  const handleClick = (id) => {
    // navigate(`/item/${id}`, { state: ad });
  };

  const handleRequestClick = () => {
    setShow(true);
  };

  const handleSelectItem = (item) => {
    setSelectedItem(item);
  };

  const handleConfirmSwap = () => {
    setShow(false);
    setSuccessMessage(true);
    // Here you would normally send the swap request to the backend
  };

  const handleClose = () => {
    setShow(false);
    setSuccessMessage(false);
  };

  return (
    <>
      <Col md={3} key={ad._id} onClick={() => handleClick(ad._id)}>
        <Card style={{ width: '100%', cursor: 'pointer' }}>
          <Card.Img
            variant="top"
            src={`${ad.imageUrl}`}
            height={300}
            style={{ objectFit: 'cover' }}
          />
          <Card.Body>
            <Card.Title
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                fontWeight: 'normal',
                fontSize: '14px',
              }}
            >
              {ad.title}
              <span style={{ userSelect: 'none' }}>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  className="bi bi-heart-fill"
                  viewBox="0 0 16 16"
                >
                  <path
                    fillRule="evenodd"
                    d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z"
                  />
                </svg>
              </span>
            </Card.Title>
            <Card.Text style={{ fontSize: '25px', fontWeight: 'bold' }}>
              Rs {ad.price}
            </Card.Text>
            <Button onClick={handleRequestClick}>Swap Request</Button>
          </Card.Body>
        </Card>
      </Col>

      {/* Modal for item selection */}
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Select an Item to Swap</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <ListGroup>
            {userItems.map((item, index) => (
              <ListGroup.Item
                key={index}
                active={selectedItem === item}
                onClick={() => handleSelectItem(item)}
                style={{ cursor: 'pointer' }}
              >
                {item.title}
              </ListGroup.Item>
            ))}
          </ListGroup>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Cancel
          </Button>
          <Button
            variant="primary"
            onClick={handleConfirmSwap}
            disabled={!selectedItem}
          >
            Confirm Swap
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Success message */}
      <Modal show={successMessage} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Success</Modal.Title>
        </Modal.Header>
        <Modal.Body>Swap request approved successfully!</Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={handleClose}>
            OK
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};
